REPDay — Android installable web app

Files:
- index.html: app
- manifest.json: install metadata
- sw.js: service worker for install support

To install on Android:
1. Host these files on an HTTPS static host (for example GitHub Pages or Netlify).
2. Open the hosted index.html URL in Chrome on Android.
3. Use Chrome menu > Install app (or Add to Home screen).
4. Open the installed app and allow notifications in Settings.

Important notification limitation:
This first version checks the reminder while the app is open or reopened. A browser-only app cannot guarantee an exact-time notification after Android fully stops it. For reliable closed-app alerts, a push service/backend or native Android app is needed.

Data is stored locally in the browser on this phone. Clearing browser/app data may erase it.
